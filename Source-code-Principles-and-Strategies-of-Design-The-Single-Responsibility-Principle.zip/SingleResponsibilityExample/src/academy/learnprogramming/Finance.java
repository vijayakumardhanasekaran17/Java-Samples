package academy.learnprogramming;

public class Finance {
    public double calcIncomeTaxForCurrentYear(Employee emp) {
        // income tax logic using employee passed in
        return 0.0;
    }
}
