package academy.learnprogramming;

import java.util.Date;

public class Employee {
    private String employeeId;
    private String name;
    private String address;
    private Date dateOfJoining;

   // getters / setters for all member variables
}